<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Modification de Contact</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container">
        <h2 class="text-center jumbotron">Gestionnaire De Contacts</h2>
        <form class="w-50 mx-auto" id="myForm" action="/update/{{$contact->id}}">
            @csrf
            @method('PUT')
            <h3 class="text-center bg-primary text-white" style="padding: 15px; border-radius: 10px; margin-bottom: 30px;" id="formHeader">Modifier Le Contact D'Id {{$contact->id}}</h3>

            <div class="form-group">
                <label for="nom">Nom: </label>
                <input class="form-control" type="text" name="nom" id="nom"
                    value="{{$contact->nom}}" required>
            </div>
    
            <div class="form-group">
                <label for="nom">Prenom: </label>
                <input class="form-control" type="text" name="prenom" id="prenom" 
                    value="{{$contact->prenom}}" required>
            </div>
    
            <div class="form-group">
                <label for="telephone">Telephone: </label>
                <input class="form-control" type="text" name="telephone" id="telephone"
                    value="{{$contact->telephone}}"  required>
            </div>
    
            <div class="form-group">
                <label for="mail">E-mail: </label>
                <input class="form-control" type="email" name="mail" id="mail" 
                     value="{{$contact->mail}}" required>
            </div>
    
            <div class="form-group">
                <label for="adresse">Adresse: </label>
                <input class="form-control" type="text" name="adresse" id="adresse"
                    value="{{$contact->adresse}}"  required>
            </div>
    
            <div class="form-group mx-auto text-center d-flex">
                <input class="form-control btn btn-danger w-50" style="margin-right: 20%;" type="submit" value="Modifier" >
                <a href="/" class="form-control btn btn-info w-50" type="button" value="Retour" >Retour</a>
            </div>
        </form>
    </div>
</body>
</html>