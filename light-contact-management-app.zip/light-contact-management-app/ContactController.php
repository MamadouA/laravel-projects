<?php

namespace App\Http\Controllers;

use App\Models\Contacts;
use Illuminate\Http\Request;


class ContactController extends Controller
{
    // show all contacts
    public function index() {
        return view('index', ['contacts' => Contacts::all()]); 
    }
    // store contact data
    public function store(Request $request) {
        $formFields = $request->all(['nom', 'prenom', 'telephone', 'mail', 'adresse']);
        Contacts::create($formFields);
        return redirect('/')->with('alert','Ajout contact reussie!');
    }

    // show edit form 
    public function edit(Contacts $contact) {
        return view('edit', ['contact'=> $contact]);
    }
    
    // update a contact
    public function update(Request $request, Contacts $contact) {
        $formFields = $request->all(['nom', 'prenom', 'telephone', 'mail', 'adresse']);

        $contact->update($formFields);

        return redirect('/')->with('alert', 'Modification du contact reussie!');
    }

    // delete a contact
    public function destroy(Contacts $contact) {
        $contact->delete();

        return redirect('/')->with('alert', 'Suppression de contact reussie!');
    }

    // show a single contact
    public function show(Contacts $contact) {
        return view('show', ['contact' => $contact]);
    }
}  
