<?php

use App\Http\Controllers\ContactController;
use App\Models\Contacts;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// show the list of the contact
Route::get('/', [ContactController::class, 'index']);

// store a new contact
Route::post('/create', [ContactController::class,'store']);

// show a form for editing a contact
Route::get('/edit/{contact}',[ContactController::class, 'edit']);

// show a form for editing a contact
Route::get('/delete/{contact}',[ContactController::class, 'destroy']);

// update a contact 
Route::get('/update/{contact}', [ContactController::class,'update']);

// show the contact's details
Route::get('/details/{contact}',[ContactController::class, 'show']);
