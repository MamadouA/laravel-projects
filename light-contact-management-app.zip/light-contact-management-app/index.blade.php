<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionnaire De Contatact</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    @if (session('alert'))
        <div class="alert alert-danger">
            {{ session('alert') }}
        </div>
    @endif
    <div class="container">
        <h2 class="text-center jumbotron">Gestionnaire De Contacts</h2>
        <!-- Nav pills -->
        <ul class="nav nav-pills" role="tablist" style="margin-bottom: 20px;">
            <li class="nav-item">
            <a class="nav-link active text-dark" data-toggle="pill" href="#home">Liste Des Contacts</a>
            </li>
            <li class="nav-item">
            <a class="nav-link  text-dark" data-toggle="pill" href="#add_contact">Ajouter Un Contact</a>
            </li>
        </ul>
        
        <!-- Tab panes -->
        <div class="tab-content">
             <!--HOME tab-->
            <div id="home" class="container tab-pane active"><br>
                <h3 class="text-center">Liste Des Contacts</h3>
                @if(!count($contacts))  <!--si la liste des contacts est vide-->
                    <p class="text-center" style="margin-top: 60px;">Pas de contact</p>
                @endif
                    <!--Card--> 
                    @foreach ($contacts as $contact)
                    <div class="card" style="width:320px; display:inline-block; margin: 5px;">
                        <img class="card-img-top" src={{asset("images/avatar-img.png")}} alt="Card image" style="width:100%; height: 210px;">
                        <div class="card-body">
                            <div class="card-text">
                            <p>Nom: {{$contact['nom']}}</p>
                            <p>Prenom: {{$contact->prenom}}</p>
                            <p>Phone Number: {{$contact->telephone}}</p>
                            </div>
                            <a href="/details/{{$contact->id}}" class="btn btn-info">Details</a>
                            <a href="/delete/{{$contact->id}}" class="btn btn-danger">Delete</a>
                            <a href="/edit/{{$contact->id}}" class="btn btn-secondary">Edit</a>
                        </div>
                    </div>
                    @endforeach
                    <!-- end Card-->
            </div>
            <!--end HOME tab-->

            <!--add contacts tab-->
            <div id="add_contact" class="container tab-pane fade">
                <form class="w-50 mx-auto" id="myForm" action="/create" method="POST">
                    @csrf
                    <h2 class="text-center" id="formHeader">Formulaire Contact</h2>
                    <hr>
            
                    <div class="form-group">
                        <label for="nom">Nom: </label>
                        <input class="form-control" type="text" name="nom" id="nom" required>
                    </div>
            
                    <div class="form-group">
                        <label for="nom">Prenom: </label>
                        <input class="form-control" type="text" name="prenom" id="prenom" required>
                    </div>
            
                    <div class="form-group">
                        <label for="telephone">Telephone: </label>
                        <input class="form-control" type="text" name="telephone" id="telephone" required>
                    </div>
            
                    <div class="form-group">
                        <label for="mail">E-mail: </label>
                        <input class="form-control" type="email" name="mail" id="mail" required>
                    </div>
            
                    <div class="form-group">
                        <label for="adresse">Adresse: </label>
                        <input class="form-control" type="text" name="adresse" id="adresse" required>
                    </div>
            
                    <div class="form-group mx-auto text-center">
                        <input class="form-control btn btn-primary w-50" type="submit" value="Soumettre" >
                    </div>
                </form>
            </div>
            <!--end add contacts tab-->
        </div>
    </div>
</body>
</html>