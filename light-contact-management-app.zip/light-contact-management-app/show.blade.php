<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container">
        <div class="jumbotron mx-auto" style="margin-top: 60px; margin-bottom: 70px; width: 75%;">
            <h1>Details Du Contact D'id 34</h1>
        </div>

        <table class="table table-striped table-hover table-bordered mx-auto" style="width: 800px;">
            <tr>
                <th>Nom</th>
                <td>{{$contact->nom}}</td>
            </tr>
            <tr>
                <th>Prenom</th>
                <td>{{$contact->prenom}}</td>
            </tr>
            <tr>
                <th>Telephone</th>
                <td>{{$contact->telephone}}</td>
            </tr>
            <tr>
                <th>Email</th>
                <td>{{$contact->mail}}</td>
            </tr>
            <tr>
                <th>Adresse</th>
                <td>{{$contact->adresse}}</td>
            </tr>
        </table>

        <div class="mx-auto text-center">
            <a href="/" class="btn btn-primary mx-auto" style="width: 70%; margin-top: 40px;">Retour</a>
        </div>
    </div>
</body>
</html>